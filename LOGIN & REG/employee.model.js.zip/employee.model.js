// USED TO CREATE/ REGISTER NEW USER

const mongoose = require("mongoose")

// IMPORT BCRYPT 
const bcrypt = require('bcrypt')

const EmployeeSchema = new mongoose.Schema({
    firstName: {
        type: String,
        required: [true, "Please add a first name"],
        minlength: [3, "First name must be at least 3 characters long"]
    },
    lastName: {
        type: String,
        required: [true, "Please add a last name"],
        minlength: [2, "Last name must be at least 2 characters long"]
    },
    email: {
        type: String,
        required: [true, "Please add a valid email"],
        // IMPORT VALIDATE TO VALIDATE EMAIL FORMAT
        validate: {
            validator: val => /^([\w-\.]+@([\w-]+\.)+[\w-]+)?$/.test(val),
            message: "Please enter a valid email"
        }

    },
    password: {
        type: String,
        required: [true, "Password is required"],
        minlength: [8, "Password must be 8 characters or longer"]

    },
    employee_id: {
        type: Number,
        // required:[true]
    }
},{timestamps: true})

// Comparing the passwords to make sure they match
EmployeeSchema.virtual('confirm')
    .get(() => this._confirmPassword)
    .set(value => this._confirmPassword = value)
// 
EmployeeSchema.pre('validate', function (next) {
    if (this.password !== this.confirm) {
        this.invalidate('confirm', 'Passwords must match')
    }
    // if the passwords match move onto the next step which would save user into db
    return next()
})

// Using bcrypt to hash the password
EmployeeSchema.pre("save", function (next) {
    console.log("password is hashed");
    // The num 10 is how many times the computer will salt the password aka making it more secure
    bcrypt.hash(this.password, 10)
        .then(hash => {
            this.password = hash
            next();
        })
        .catch(error => {
            console.log("Unable to Hash password", error)
            next();
        })
})



const Employee = mongoose.model("Baddie_employee", EmployeeSchema)
module.exports = Employee;