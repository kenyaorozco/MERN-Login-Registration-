const Employee = require("../controllers/employee.controller");
const {authenticate} = require("../config/jwt")


console.log(Employee)

module.exports = (app) => {
    // CREATE new user
    app.post("/new/user",Employee.register)
    // LOGIN
    app.post("/user/login",Employee.oneEmployee)
    // AFTER LOGGIN GET USER LOGGIn
    app.get("/logged/in/user",authenticate, Employee.loggedInEmployee)
    // LOGOUT 
    app.get("/logout",Employee.logout)

}