import axios from 'axios'
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'


const Login = () => {
    const navigate = useNavigate();

    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')

    const [error, setError] = useState('')

    const login = (e) => {
        e.preventDefault();
        axios.post("http://localhost:8000/user/login", {
            email,
            password
        }, { withCredentials: true })
            .then(result => {
                console.log(result.data)
                if (result.data.msg === "success!") {
                    navigate("/inventory")
                } else {
                    setError(result.data.msg)
                }
            })
            .catch(error => {
                console.log(error)
            })
    }


    return (
        <form onSubmit={login}>
            <h2>Login</h2>
            {error ? <p className='text-danger'>{error}</p> : ""}
            <div style={{ display: "inline-block", width: "50%" }}>
                <div style={{ display: "flex", flexDirection: "column" }}>

                    <label>Email:</label>
                    <input name="email" onChange={(e => setEmail(e.target.value))} value={email} />
                    <label>password</label>
                    <input name="password" onChange={(e => setPassword(e.target.value))} type="password" value={password} />
                </div>
                    <button>Log in</button>
            </div>
        </form>
    )
}

export default Login