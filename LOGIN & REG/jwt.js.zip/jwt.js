const jwt = require("jsonwebtoken");
const secret ="no one knows"
// Import JSON WEB TOKEN 

// Need to have a secret key 

module.exports.secret = secret;

module.exports.authenticate = (req, res, next) => {
// USE JWT to verify the cookie, ex:session in python
    jwt.verify(req.cookies.usertoken, secret, (err, payload) => {
        if (err) {
            res.status(401).json({ verified: false });
        } else {
            next();
        }
    });
}

