const express = require ('express');
const app = express();
const PORT = 8000;
// const cookies = require('cookie-parser');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const DB = "DA_BADDIES";


// In our DB name there can't be any spaces

//--- MIDDLEWARE ---
app.use(cors({credentials: true, origin: 'http://localhost:3000'}));
app.use(cookieParser());
app.use(express.json(),express.urlencoded({extended:true}));

// ---USE TO CONNECT DB TO OUR CONFIG --
require("./config/mongoose.config")(DB)
require('dotenv').config();


// connect to DB FIRst THEN connect to the routes 
require('./routes/baddie.route')(app)
require('./routes/employee.route')(app)
//  the APP invokes our function on our ROUTE controller


// ---Starts the server---
app.listen(PORT,() => {console.log(`Server up on  PORT ${PORT}`)}) 