const Employee = require("../models/employee.model");

const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')


const {secret} = require('../config/jwt')
// const myFirstSecret = process.env.FIRST_SECRET_KEY;


// REGISTER NEW USER
module.exports.register = (req, res) => {
    Employee.create(req.body)
        .then(user => {
            res.json({ msg: "success!", user: user });
        })
        .catch(err => res.json(err));
}


// LOGIN  
module.exports.oneEmployee = (request, result) => {
    console.log(request.body.email);
    Employee.findOne({ email: request.body.email })
        .then(employee => {
            console.log(employee)
            if ( employee === null) {
                res.status(400).json({ error: "Employee not found error" });
            } else {
                console.log(request.body.password, employee.password);
                bcrypt.compare(request.body.password, employee.password)
                .then(passwordIsValid => {
                    // console.log(passwordIsValid);
                        if (passwordIsValid) {
                            result.cookie("usertoken", jwt.sign({ _id: employee._id }, secret), { httpOnly: true })
                                .json({ msg: "success!" });
                        } else {
                            result.json({ msg: "invalid login attempt" })
                        }
                    })
                    .catch(error => result.json({ msg: "invalid login attempt- password attempt", error }))
            }
        })
        .catch(error => result.json({ msg: "invalid email ", error }))
}



// VERIFY USER
module.exports.loggedInEmployee = (request, result) => {
    const decodedJWT = jwt.decode(request.cookies.usertoken, { complete: true })

    Employee.findById(decodedJWT.payload._id)
        .then(employee => result.json(employee))
        .catch(err => result.json(err))
}

// LOGOUT 
module.exports.logout = (request,result) => {
    result.cookie("usertoken", jwt.sign({_id:""},secret), {
        httpOnly:true,
        maxAge: 0

    }).json({msg:'ok'})
}

