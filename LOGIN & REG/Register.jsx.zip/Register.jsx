import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import axios from 'axios'

const Register = () => {
    const navigate = useNavigate();

    const [formInfo, setFormInfo] = useState({
        firstName: "",
        lastName: "",
        email: "",
        password: "",
        employee_id: ""
    })

    const [errors, setErrors] = useState({})


    const changehandler = (e) => {
        e.preventDefault();
        setFormInfo({
            ...formInfo,
            [e.target.name]: e.target.value

        })
    }
    const register = (e) => {
        e.preventDefault();
        axios.post("http://localhost:8000/new/user", formInfo, { withCredentials: true })
            .then(result => {
                console.log(result)
                if (result.data.errors) {
                    setErrors(result.errors)
                } else {
                    navigate("/login")
                }
            })
            .catch(error => {
                console.log(error)
                navigate("/register")
            })
    }


    return (
        <fieldset>

            <form onSubmit={register}>
                <h2>Create an Account</h2>
                <div style={{ display: "inline-block", width: "50%" }}>
                    <div style={{ display: "flex", flexDirection: "column" }}>

                        <label> First Name</label>
                        <input name="firstName" onChange={changehandler} />
                        {errors.firstName ? <p className='text-danger'>{errors.firstName.message}</p> : ""}

                        <label>Last Name</label>
                        <input name="lastName" onChange={changehandler} />
                        {errors.lastName ? <p className='text-danger'>{errors.lastName.message}</p> : ""}

                        <label>Email</label>
                        <input name="email" onChange={changehandler} />
                        {errors.email ? <p className='text-danger'>{errors.email.message}</p> : ""}

                        <label> Password</label>
                        <input type="password" name="password" onChange={changehandler} />
                        {errors.password ? <p className='text-danger'>{errors.password.message}</p> : ""}

                        <label>Confirm Password</label>
                        <input type="password" name="confirm" onChange={changehandler} /> <br />
                        {errors.confirm ? <p className='text-danger'>{errors.confirm.message}</p> : ""}

                        <label>Employee ID</label>
                        <input name='employee_id' type="Number" onChange={changehandler} />
                        {errors.employee_id ? <p className='text-danger'>{errors.employee_id.message}</p> : ""}

                    </div>
                    <button>Create </button>
                </div>

            </form>
        </fieldset>

    )
}

export default Register